#include "data_controller.h"

Data_Controller::Data_Controller(QObject *parent) : QObject(parent)
{
    league_index="XiJia";
    team_name="Xijia 球队0";
}
/*Data_Controller::~Data_Controller()
{

}*/
void Data_Controller::setLeagueData(QString leaguename)
{
    league_index=leaguename;
    qDebug("LeagueName has been changed");
    qDebug(leaguename.toUtf8().data());
    emit leagueDataChanged(league_index);
}
void Data_Controller::setTeamData(QString teamname)
{
    team_name=teamname;
    qDebug("TeamData has been changed");
    qDebug(teamname.toUtf8().data());
    emit teamDataChanged(team_name);
}
QString Data_Controller::getLeague()const
{
    return league_index;
}
QString Data_Controller::getTeamName()const
{
    return team_name;
}

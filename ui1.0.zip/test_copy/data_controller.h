#ifndef DATA_CONTROLLER_H
#define DATA_CONTROLLER_H

#include <QObject>

class Data_Controller : public QObject
{
    Q_OBJECT
    //Q_ENUMS(League)
    Q_PROPERTY(QString TeamName READ getTeamName WRITE setTeamData NOTIFY teamDataChanged)
    Q_PROPERTY(QString LeagueName READ getLeague WRITE setLeagueData NOTIFY leagueDataChanged)
public:
    explicit Data_Controller(QObject *parent = 0);
    /*enum League{
        XiJia,
        DeJia,
        YinChao,
        YiJia
    };*/
    QString getTeamName()const;
    QString getLeague()const;
signals:
    void teamDataChanged(const QString teamname);
    void leagueDataChanged(const QString leaguename);
public slots:
    void setTeamData(QString teamname);
    void setLeagueData(QString leaguename);
private:
     //League league_index;
     QString league_index;
     //需要建立数据结构存储信息
     QString team_name;
};

#endif // DATA_CONTROLLER_HT

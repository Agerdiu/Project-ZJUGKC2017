#ifndef DATA_CONTROLLER_H
#define DATA_CONTROLLER_H

#include <QObject>
#include "teamdata.h"
class Data_Controller : public QObject
{
    Q_OBJECT
    /*Q_ENUMS(League)*/
    Q_PROPERTY(QString TeamName READ getTeamName WRITE setTeamData NOTIFY teamDataChanged)
    Q_PROPERTY(QString LeagueName READ getLeague WRITE setLeagueData NOTIFY leagueDataChanged)
public:
    explicit Data_Controller(QObject *parent = 0);
    /*enum League{
        XiJia,
        DeJia,
        YinChao,
        YiJia
    };*/
    //给积分榜提供球队成员名单
     Q_INVOKABLE QList<QObject*> getTeamList(QString league_index);
    QString getTeamName()const;
    QString getLeague()const;
signals:
    void teamDataChanged(const QString teamname);
    void leagueDataChanged(const QString leaguename);
    void signalList(QList<QObject*> data);
public slots:
    void setTeamData(QString teamname);
    void setLeagueData(QString leaguename);
private:
     //记录当前点击联赛名称
     QString league_index;
     //记录当前所点球队名称
     QString team_name;
     QList<QObject*>teamlist;
};

#endif // DATA_CONTROLLER_HT
